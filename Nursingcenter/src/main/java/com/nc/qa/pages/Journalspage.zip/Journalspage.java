package com.nc.qa.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.nc.qa.base.TestBase;

public class Journalspage extends TestBase {

   @FindBy(xpath="//a[text()='Journals & Articles']")
	WebElement journalsAndArticles;
//	@FindBy(id="p_lt_zonePageLeftPlaceholder_SmartLoginCtrl_txtInputPassword")
//	WebElement password;
   @FindBy(xpath="//a[text()='Journals']")
   WebElement journals;
   //@FindBy(xpath="//img[@alt='Nursing-(13).png'][@src='/getattachment/Journals-Articles/Journals/Nursing-(13).png.aspx']")
   @FindBy(xpath="//a[text()='Nursing2019'][1]")
   WebElement clickonBook;
   @FindBy(xpath="//a[text()='Got it!']")
   WebElement cookies;
   @FindBy(css="a#p_lt_zonePagePlaceholder_ArticleAndEbookControl_ctl00_ArticleMenu_lnkFileDrawer")
   WebElement addbookmark;
 Actions a=new Actions(driver);

public Journalspage() throws Exception {
		
	}
public void journals() throws InterruptedException
{
	cookies.click();
	driver.manage().window().maximize();
	a.moveToElement(journalsAndArticles).build().perform();
	journals.click();
	Thread.sleep(4000);
	clickonBook.click();
	Thread.sleep(5000);
//List<WebElement> alllist=driver.findElements(By.xpath("//div[@class='col-md-1 col-sm-12 col-xs-12']/span"));

	List<WebElement> alllist=driver.findElements(By.xpath("//span[contains(@class,'badge     badge-free')]/following::a"));
	for(WebElement element:alllist)
	{
		System.out.println(element.getText());
		List<WebElement> free=driver.findElements(By.xpath("//div[@class='col-md-1 col-sm-12 col-xs-12']/span"));
		for(WebElement ele:free) 
		{
	if(ele.getText().contains("Free"))
		{
			
			//List<WebElement> free=driver.findElements(By.xpath("//span[contains(@class,'badge     badge-free')]/following::a"));
			
			//for(WebElement ele:free)
			//{
				System.out.println(ele.getText());
			a.click(element).build().perform();
			addbookmark.click();
			String Url=driver.getCurrentUrl();
			System.out.println(Url);
		}
	}
		/*for(int i=0;i<alllist.size();i++)
		{
			Thread.sleep(5000);
		8	System.out.println(alllist.get(i).getText());
			if(alllist.get(i).getText().contains("Free"))
			{
				System.out.println("hi");
		alllist.get(i).click();
				//boolean free=alllist.get(1).getText().contains("Free");
				//String all=alllist.get(i).getTagName().equalsIgnoreCase("Free")
			}
		}*/
	

}

}}
